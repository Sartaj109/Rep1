package com.cg.uas.entities;

import java.io.Serializable;

public class Programs_Scheduled implements Serializable{

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private String scheduledProgramId;
	private String programName;
	private String location;
	private String startDate;
	private String endDate;
	private int sessionsPerWeek;
	
	public Programs_Scheduled() {
		super();
	}
	public Programs_Scheduled(String scheduledProgramId, String programName, String location, String startDate,
			String endDate, int sessionsPerWeek) {
		super();
		this.scheduledProgramId = scheduledProgramId;
		this.programName = programName;
		this.location = location;
		this.startDate = startDate;
		this.endDate = endDate;
		this.sessionsPerWeek = sessionsPerWeek;
	}
	public String getScheduledProgramId() {
		return scheduledProgramId;
	}
	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public int getSessionsPerWeek() {
		return sessionsPerWeek;
	}
	public void setSessionsPerWeek(int sessionsPerWeek) {
		this.sessionsPerWeek = sessionsPerWeek;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((scheduledProgramId == null) ? 0 : scheduledProgramId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Programs_Scheduled other = (Programs_Scheduled) obj;
		if (scheduledProgramId == null) {
			if (other.scheduledProgramId != null)
				return false;
		} else if (!scheduledProgramId.equals(other.scheduledProgramId))
			return false;
		return true;
	}
	
}