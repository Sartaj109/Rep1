package com.cg.uas.ui;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Offered;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exceptions.UasException;
import com.cg.uas.services.AdminServiceImpl;
import com.cg.uas.services.ApplicantService;
import com.cg.uas.services.ApplicantServiceImpl;
import com.cg.uas.services.MacService;
import com.cg.uas.services.MacServiceImpl;

/************************************************************************************
 * File:        Client.java
 * Package:     com.cg.uas.client
 * Desc:        Class implementing main method i.e. starting point of application
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	15/12/2017  
 * Modifications:  
 * Change Description:
 ************************************************************************************/

public class Client {
	
	static Scanner sc = new Scanner(System.in);
	private static AdminServiceImpl adminService;
	private static ApplicantServiceImpl appService;
	private static MacServiceImpl macService;
	/*private*/ static Applicant app = new Applicant();
	private static Programs_Offered programOff;
	private static Programs_Scheduled programSch;
	public Client() throws UasException {
		adminService=new AdminServiceImpl();
		appService=new ApplicantServiceImpl();
		macService=new MacServiceImpl();
//		app=new Applicant();
		programOff=new Programs_Offered();
		programSch=new Programs_Scheduled();
	}
	/**
	 * @throws UasException 
	 * @throws SQLException 
	 *
	 */
	
	
	public static void main(String[] args) throws UasException, SQLException
	{
		int option=0;
		showMenu();
		exit:
		while(true)
		{
				option = sc.nextInt();
				
				switch (option) {
				case 1:
					applicant();
					break;
				case 2:
					admin();
					break;
				case 3:
					admissCommittee();
					break;
				case 4:
					System.out.println("==================================================="
							+ "Thank You For Using  University Admission System"
							+ "===================================================");
					break exit;
				default:
					System.out.println("Enter a valid option[1-4]");
				}
			} 
	}
	
	
	/*****************************************************************
	 * - Method Name: showMenu() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 15/12/2017 
	 * - Description : Show the login menu to the user
	 *******************************************************************/
	
	private static void showMenu() {
		System.out
				.println("\n_____________________________________________________________________________________________\n"
						+ "\n                                 University Admission System "
						+ "\n_____________________________________________________________________________________________\n"
						+ "\n                                 1.Applicant"
						+ "\n                                 2.Admin"
						+ "\n                                 3.Admin Commitee"
						+ "\n                                 4.Exit"
						+ "\n______________________________________________________________________________________________");
		System.out.println("Select an option(1/2/3/4):");

	}
	
	/*****************************************************************
	 * - Method Name: applicant() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Execute methods to provide option to select from menu for applicant
	 * @throws SQLException 
	 * @throws UasException 
	 *******************************************************************/
	
	private static void applicant() throws UasException, SQLException
	{
		int option=0;
		exit:
		while(true)
		{
				
				applicantMenu();
				option = sc.nextInt();
				switch (option) {
				case 1:
					applyPrograms();//Show programs and apply option
					break;
				case 2:
					checkAppStatus();
					break;
				case 3:
					showMenu(); //Go back to main menu
					break exit;
				default:
					System.out.println("Enter a valid option[1-4]");
				}
			} 
	}
	
	
	/*****************************************************************
	 * - Method Name: admissCommittee() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Execute methods to provide option to select from menu for admission committee
	 * @throws UasException 
	 *******************************************************************/
	
	private static void admissCommittee() throws UasException
	{
		String userName;
		String password;
		while(true)
		{
			System.out.println("Enter mac username: ");
			userName = sc.next();
			System.out.println("Enter mac password: ");
			password = sc.next();
			if(userName.equals("admin") && password.equals("admin")) //Compare admin username and password 
			{
				break;
			}
			else
			{
				System.out.println("Wrong username/password. Try again. ");
			}
		}
		int option=0;
		exit:
		while(true)
		{
				admissCommitteeMenu();
				option = sc.nextInt();
				switch (option) {
				case 1:
					viewApplications(); //For a specific program
					break;
				case 2:
					manageApplications(); //Accept/reject applications
					break;
				case 3:
					updateStatus();
					break;
				case 4:
					showMenu();  //Go back to main menu
					break exit;
				default:
					System.out.println("Enter a valid option[1-4]");
				}
			} 
	}

	
	/*****************************************************************
	 * - Method Name: admin() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Execute methods to provide option to select from menu for admin
	 * @throws SQLException 
	 * @throws UasException 
	 *******************************************************************/
	
	private static void admin() throws UasException, SQLException
	{
		int option=0;
		String userName;
		String password;
		while(true)
		{
			System.out.println("Enter admin username: ");
			userName = sc.next();
			System.out.println("Enter admin password: ");
			password = sc.next();
			if(userName.equals("admin") && password.equals("admin")) //Compare admin username and password 
			{
				break;
			}
			else
			{
				System.out.println("Wrong username/password. Try again. ");
			}
		}

		exit:
		while(true)
		{
				adminMenu();
				option = sc.nextInt();
				switch (option) {
				case 1:
					addProgram();
					break;
				case 2:
					updateProgram();
					break;
				case 3:
					deleteProgram();
					break;
				case 4:
					addSchedule();
					break;
				case 5:
					deleteSchedule();
					break;
				case 6:
					listOfApplicants(); //list of confirmed/accepted applicants
					break;
				case 7:
					listInGivenTime(); //list of programs scheduled in a given time period
					break;
				case 8:
					showMenu();  //Go back to main menu
					break exit;
				default:
					System.out.println("Enter a valid option[1-8]");
				}
			} 
	}

	

	/*****************************************************************
	 * - Method Name: applicantMenu() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Show applicant menu options
	 *******************************************************************/
	
	private static void applicantMenu()
	{
		System.out
		.println("\n_____________________________________________________________________________________________\n"
				+ "\n                                 Applicant Menu "
				+ "\n_____________________________________________________________________________________________\n"
				+ "\n                                 1.View and apply for programs"
				+ "\n                                 2.Check Applicant Status"
				+ "\n                                 3.Main Menu"
				+ "\n                                 4.Exit"
				+ "\n______________________________________________________________________________________________");
		System.out.println("Select an option(1/2/3):");

	}
	
	/*****************************************************************
	 * - Method Name: applyPrograms() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Enable user to apply for particular program
	 * @throws SQLException 
	 * @throws UasException 
	 *******************************************************************/
	
	private static void applyPrograms() throws UasException, SQLException
	{
		
		//Fetch from database
		
		//Enter applicant details after entering correct program id
		while(true)
		{
			System.out.println("Enter the Program Id you want to apply for: ");
			System.out.println("Enter Student Name : ");
			String name=sc.next();
			System.out.println(name);
			app.setFullName(name);
			System.out.println("Enter Date of birth: ");
			String date = sc.next();
			
//			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("DD-MM-YYYY");
//			LocalDate ld = LocalDate.parse(date, dtf);
			app.setDateOfBirth(date);
			System.out.println("Enter Highest Qualifications : ");
			app.setHighestQualification(sc.next());
			System.out.println("Enter highest marks obtained : ");
			app.setMarksObtained(sc.nextInt());
			System.out.println("Enter Goals : ");
			app.setGoals(sc.next());
			System.out.println("Enter Email Id : ");
			//String emailId = sc.nextLine();
			app.setEmailId(sc.nextLine());
			
			
			appService.addNewApplicant(app);
			int input = sc.nextInt();
			if(input == 1) //Check with database
			{
				inAppDetails();
				break;
			}
		}
	}
	
	/*****************************************************************
	 * - Method Name: checkAppStatus() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 15/12/2017 
	 * - Description : Check status of application
	 * @throws SQLException 
	 * @throws UasException 
	 *******************************************************************/
	
	@SuppressWarnings("unused")
	private static void checkAppStatus() throws UasException, SQLException
	{
		System.out.println("Enter application Id: ");
		String applicationId = sc.next();
		appService.getApplicantStatus(applicationId);
		//Check if input matches with application Id in Database
		if(true)
		{
			System.out.println("Application Id: ");
			System.out.println("Applicant Name: ");
			System.out.println("Status: ");
		}
		else
		{
			System.out.println("Enter correct Application Id.");
		}
	}
	
	/*****************************************************************
	 * - Method Name: inAppDetails() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Ask applicant to input details
	 *******************************************************************/
	private static void inAppDetails()
	{
		System.out
		.println("\n_____________________________________________________________________________________________\n"
				+ "\n                                 Enter Applicant Details "
				+ "\n_____________________________________________________________________________________________\n");
		
		
		//APPLY PATTERN ON THE INPUT
		String fullName;
		String date;
		String highestQualification;
		int marksObtained;
		String goals;
		String emailId;
		String scheduledProgramId;
		
		System.out.println("List all program details");
		
		System.out.println("Enter full name: ");
		sc.nextLine();
		fullName = sc.nextLine();
		System.out.println("Enter date of birth(dd/mm/yyyy): ");
		date = sc.nextLine();
		System.out.println("Enter highest qualification: ");
		highestQualification = sc.nextLine();
		System.out.println("Enter marks obtained: ");
		marksObtained = sc.nextInt();
		System.out.println("Enter goals: ");
		sc.nextLine();
		goals = sc.nextLine();
		System.out.println("Enter Email: ");
		emailId = sc.nextLine();
		System.out.println("Enter Program ID: ");
		scheduledProgramId = sc.nextLine();
		
//		Date dateOfBirth = Date.valueOf(date);
		
		//Test input
		System.out.println(fullName+" "+highestQualification+" "+marksObtained+" "+goals+" "+emailId+" "+scheduledProgramId);
		
		//Auto-generate Application ID
	}
	
	
	/*****************************************************************
	 * - Method Name: adminMenu() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Show admin menu options
	 *******************************************************************/
	
	private static void adminMenu()
	{
			System.out
			.println("\n_____________________________________________________________________________________________\n"
					+ "\n                                 Admin Menu "
					+ "\n_____________________________________________________________________________________________\n"
					+ "\n                                 1.Add Program"
					+ "\n                                 2.Update Program"
					+ "\n                                 3.Delete Program"
					+ "\n                                 4.Add Schedule"
					+ "\n                                 5.Delete Schedule"
					+ "\n                                 6.List of confirmed applicants"
					+ "\n                                 7.List of programs scheduled in a given time period"
					+ "\n                                 8.Go to Main Menu"
					+ "\n______________________________________________________________________________________________");
			System.out.println("Select an option(1/2/3/4/5/6/7/8):");

		}
	
	/*****************************************************************
	 * - Method Name: addProgram() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Add program to database
	 * @throws SQLException 
	 * @throws UasException 
	 *******************************************************************/
	private static void addProgram() throws UasException, SQLException
	{
		
		adminService.addProgram(programOff);
		
	}
	
	/*****************************************************************
	 * - Method Name: updateProgram() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Update program details in database
	 * @throws SQLException 
	 * @throws UasException 
	 *******************************************************************/
	private static void updateProgram() throws UasException, SQLException
	{
		
		String programName = null;
		String newData=null;
		int choice=0;
		adminService.updateProgram(programName, newData, choice);
		
	}
	
	/*****************************************************************
	 * - Method Name: deleteProgram() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Delete program from database
	 * @throws SQLException 
	 * @throws UasException 
	 *******************************************************************/
	private static void deleteProgram() throws UasException, SQLException
	{
		
		String programName = null;
		adminService.deleteProgram(programName);
		
	}
	
	/*****************************************************************
	 * - Method Name: addSchedule() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Add schedule to database
	 * @throws SQLException 
	 * @throws UasException 
	 *******************************************************************/
	private static void addSchedule() throws UasException, SQLException
	{
		
		adminService.addSchedule(programSch);
		
	}
	
	/*****************************************************************
	 * - Method Name: deleteSchedule() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Delete schedule from database
	 * @throws SQLException 
	 * @throws UasException 
	 *******************************************************************/
	private static void deleteSchedule() throws UasException, SQLException
	{
		String scheduledProgramId = null;
		adminService.deleteSchedule(scheduledProgramId);
		
		
	}
	
	/*****************************************************************
	 * - Method Name: listOfApplicants() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Get list of all confirmed applicants
	 * @throws SQLException 
	 * @throws UasException 
	 *******************************************************************/
	private static void listOfApplicants() throws UasException, SQLException
	{
		
		String status = null;
		adminService.getApplicantList(status);
		
	}
	
	

	/*****************************************************************
	 * - Method Name: listInGivenTime() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Get list of programs scheduled in a given time period
	 * @throws SQLException 
	 * @throws UasException 
	 *******************************************************************/
	private static void listInGivenTime() throws UasException, SQLException
	{
		
		String startDate = null;
		String endDate = null;
		adminService.getProgramSchedule(startDate, endDate);
		
	}
	
	
	
	/*****************************************************************
	 * - Method Name: viewApplications() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : View applications for a specific program
	 * @throws UasException 
	 *******************************************************************/
	private static void viewApplications() throws UasException
	{
		String scheduledProgramId;
		while(true)
		{
			System.out.println("Enter the program id: ");
			scheduledProgramId = sc.next();
			macService.viewApllications(scheduledProgramId);
		}
	}
	
	/*****************************************************************
	 * - Method Name: manageApplications() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Accept/Reject and fill in scheduled date for interview
	 * @throws UasException 
	 *******************************************************************/
	private static void manageApplications() throws UasException
	{
		String status = null;
		String applicationId;
		String scheduledProgramId = null;
		System.out.println("Details of all applinats are here.");
		macService.viewApllications(scheduledProgramId);
		System.out.println("Enter application Id: ");
		applicationId = sc.next();
		System.out.println("Use "+applicationId+" to accept/reject application and fill in scheduled date");
		macService.updateStatus(applicationId);
		macService.setStatus(status, applicationId);
	} 
	
	/*****************************************************************
	 * - Method Name: updateStatus() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Update status of application to confirmed/rejected
	 *******************************************************************/
	private static void updateStatus()
	{
		String applicationId;
		while(true)
		{
			System.out.println("Enter the application Id: ");
			sc.nextLine();
			applicationId = sc.nextLine();
			if(true) //Check if app id exists
			{
				break;
			}
		}
		
		System.out.println("Change status where app id is = "+applicationId);

	}
	

	/*****************************************************************
	 * - Method Name: admissCommittee() 
	 * - Input Parameters : 
	 * - Return Type : void 
	 * - Author : Capgemini 
	 * - Creation Date : 16/12/2017 
	 * - Description : Show admission committee menu options
	 *******************************************************************/
	
	private static void admissCommitteeMenu()
	{	
		System.out
		.println("\n_____________________________________________________________________________________________\n"
				+ "\n                                 Admission Committee Menu "
				+ "\n_____________________________________________________________________________________________\n"
				+ "\n                                 1.View applications for specific program"
				+ "\n                                 2.Accept/Reject Applications"
				+ "\n                                 3.Change status of applications"
				+ "\n                                 4.Main Menu"
				+ "\n______________________________________________________________________________________________");
		System.out.println("Select an option(1/2/3):");

	}
	
	}