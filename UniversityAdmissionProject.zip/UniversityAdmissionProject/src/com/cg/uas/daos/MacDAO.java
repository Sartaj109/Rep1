package com.cg.uas.daos;

import java.util.ArrayList;

import com.cg.uas.entities.Applicant;
import com.cg.uas.exceptions.UasException;

public interface MacDAO {
	ArrayList<Applicant> viewApplications(String scheduledProgramId) throws UasException;
	int updateStatus(String applicationId) throws UasException; 
	boolean setStatus(String status,String applicationId) throws UasException;
}