
package com.cg.uas.daos;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Offered;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exceptions.UasException;

public interface AdminDAO {
	boolean addProgram(Programs_Offered po) throws UasException, SQLException;
	boolean deleteProgram(String programName) throws UasException, SQLException;
	boolean updateProgram(String programName,String newData,int choice) throws UasException, SQLException;
	String addSchedule(Programs_Scheduled ps) throws UasException, SQLException; 
	boolean deleteSchedule(String scheduledProgramId) throws UasException, SQLException;
	ArrayList<Applicant>  getApplicantList(String status) throws UasException, SQLException;
	ArrayList<Programs_Scheduled> getProgramSchedule(String startDate,String endDate) throws UasException, SQLException;
}
