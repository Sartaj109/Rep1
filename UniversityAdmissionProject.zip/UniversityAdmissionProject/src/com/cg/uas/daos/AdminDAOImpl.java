package com.cg.uas.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.uas.util.DBUtil;

import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Offered;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exceptions.UasException;
//import com.cg.uas.util.DBUtil;
//import com.cg.uas.util.DBUtilFactory;

public class AdminDAOImpl implements AdminDAO {
//	private DBUtil DBUtil;
	
//	public AdminDAOImpl() throws UasException {
//		DBUtilFactory DBUtilFactory = new DBUtilFactory(); // Create instance of data source factory
//		DBUtil = DBUtilFactory.getDBUtil(); // Initialize the data source
//	}
	@Override
	public boolean addProgram(Programs_Offered po) throws UasException, SQLException {
		String query = "insert into Programs_Offered values(?,?,?,?,?)";
		try
		(
			Connection connection = DBUtil.getConnection(); // Retrieve connection from the data source
			PreparedStatement statement = connection.prepareStatement(query); // Create a prepared statement
		)
		{
			try {
				String programName=po.getProgramName();
				String description=po.getDescription();
				String applicantEligibility=po.getApplicantEligibility();
				int duration=po.getDuration();
				String degreeCertificateOffered=po.getDegreeCertificateOffered();
				statement.setString(1, programName);
				statement.setString(2, description);
				statement.setString(3, applicantEligibility);
				statement.setInt(4, duration);
				statement.setString(5, degreeCertificateOffered);
				statement.executeQuery();
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
			
		}
	}

	@Override
	public boolean deleteProgram(String programName) throws UasException, SQLException {
		String query="delete from Application where Scheduled_program_id=(select Scheduled_program_id from Programs_Scheduled where ProgramName like ?)";
		String query1="delete from Programs_Scheduled where ProgramName like ?";
		String query2 = "delete from Programs_Offered where ProgramName like ?";
		try
		(
			Connection connection = DBUtil.getConnection(); // Retrieve connection from the data source
			PreparedStatement statement = connection.prepareStatement(query);
			PreparedStatement statement1 = connection.prepareStatement(query1);
			PreparedStatement statement2 = connection.prepareStatement(query2);// Create a prepared statement
		)
		
		{
			try {
				statement.setString(1, programName);
				statement1.setString(1, programName);
				statement2.setString(1, programName);
				statement.execute();
				statement1.execute();
				statement2.execute();
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
			
		}
	}

	@Override
	public boolean updateProgram(String programName,String newData,int choice) throws UasException, SQLException {
		String query = null;
		//"insert into Programs_Offered values(?,?,?,?,?)";
		PreparedStatement statement=null;
		try
		(
			Connection connection = DBUtil.getConnection(); // Retrieve connection from the data source
			 // Create a prepared statement
		)
		{
			try {
				switch(choice)
				{
				case 1:query="update Programs_Offered set description=? where ProgramName=?";
				statement=connection.prepareStatement(query);
				statement.setString(1, newData);
				statement.setString(2, programName);
				statement.execute();
				return true;
				case 2:query="update Programs_Offered set applicant_eligibility=? where ProgramName=?";
				statement=connection.prepareStatement(query);
				statement.setString(1, newData);
				statement.setString(2, programName);
				statement.execute();
				return true;
				case 3:query="update Programs_Offered set duration=? where ProgramName=?";
				int newData1=Integer.parseInt(newData);
				statement=connection.prepareStatement(query);
				statement.setInt(1, newData1);
				statement.setString(2, programName);
				statement.execute();
				return true;
				case 4:query="update Programs_Offered set degree_certificate_offered=? where ProgramName=?";
				statement=connection.prepareStatement(query);
				statement.setString(1, newData);
				statement.setString(2, programName);
				statement.execute();
				return true;
				}
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}finally {
				statement.close();
			}
		}
	}

	@Override
	public String addSchedule(Programs_Scheduled ps) throws UasException, SQLException {
		String query = "insert into Programs_Scheduled values(?,?,?,?,?,?)";
		try
		(
			Connection connection = DBUtil.getConnection(); // Retrieve connection from the data source
			PreparedStatement statement = connection.prepareStatement(query); // Create a prepared statement
		)
		{
			try {
				String scheduledProgramId=ps.getScheduledProgramId();
				String programName=ps.getProgramName();
				String location=ps.getLocation();
				String startDate=ps.getStartDate();
				String endDate=ps.getEndDate();
				int sessionsPerWeek=ps.getSessionsPerWeek();
				statement.setString(1, scheduledProgramId);
				statement.setString(2, programName);
				statement.setString(3, location);
				statement.setString(4, startDate);
				statement.setString(5, endDate);
				statement.setInt(6, sessionsPerWeek);
				statement.execute();
				return scheduledProgramId;
			} catch (SQLException e) {
				e.printStackTrace();
				return null;
			}
			
		}
	}

	@Override
	public boolean deleteSchedule(String scheduledProgramId) throws UasException, SQLException {
		String query="delete from Application where Scheduled_program_id=?";
		String query1="delete from Programs_Scheduled where Scheduled_program_id=?";
		try
		(
			Connection connection = DBUtil.getConnection(); // Retrieve connection from the data source
			PreparedStatement statement = connection.prepareStatement(query);
			PreparedStatement statement1 = connection.prepareStatement(query1);
		)
		{
			try {
				statement.setString(1, scheduledProgramId);
				statement1.setString(1, scheduledProgramId);
				statement.execute();
				statement1.execute();
				return true;
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
	}

	@Override
	public ArrayList<Applicant> getApplicantList(String status) throws UasException, SQLException {
		ArrayList<Applicant> appList=new ArrayList<>();
		String query="select Application_id,full_name,date_of_birth,highest_qualification,marks_obtained,"+
		"goals,email_id,Scheduled_program_id,status,Date_Of_Interview where status=?";
		try(
				Connection connection = DBUtil.getConnection(); 
				PreparedStatement statement = connection.prepareStatement(query);
				ResultSet rs=statement.executeQuery(query);
		)
		{
			while(rs.next())
			{
				String applicationId=rs.getString(1);
				String fullName=rs.getString(2);
				String dateOfBirth=rs.getString(3);
				String highestQualification=rs.getString(4);
				int marksObtained=rs.getInt(5);
				String goals=rs.getString(6);
				String emailId=rs.getString(7);
				String scheduledProgramId=rs.getString(8);
				String appstatus=rs.getString(9);
				String dateOfInterview=rs.getString(10);
				Applicant app=new Applicant(applicationId, fullName, dateOfBirth, highestQualification, marksObtained, goals, emailId, scheduledProgramId, appstatus, dateOfInterview);
				appList.add(app);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return appList;
	}

	@Override
	public ArrayList<Programs_Scheduled> getProgramSchedule(String startDate, String endDate) throws UasException, SQLException {
		ArrayList<Programs_Scheduled> proList=new ArrayList<>();
		ResultSet rs=null;
		String query="select Scheduled_program_id,ProgramName,Location,start_date,end_date,sessions_per_week from Programs_Scheduled where 	start_date>=? and end_date<=?";
		try(
				Connection connection = DBUtil.getConnection(); 
				PreparedStatement statement = connection.prepareStatement(query);
		)
		{
			statement.setString(1, startDate);
			statement.setString(2, endDate);
			rs=statement.executeQuery(query);
			while(rs.next())
			{
				String scheduledProgramId=rs.getString(1);
				String programName=rs.getString(2);
				String location=rs.getString(3);
				String startDatePro=rs.getString(4);
				String endDatePro=rs.getString(5);
				int sessionsPerWeek=rs.getInt(6);
				Programs_Scheduled pro=new Programs_Scheduled(scheduledProgramId, programName, location, startDatePro, endDatePro, sessionsPerWeek);
				proList.add(pro);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}finally
		{
			rs.close();
		}
		return proList;
	}

}
