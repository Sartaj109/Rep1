package com.cg.uas.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

//import com.cg.cms.exceptions.CustomerException;
import com.cg.uas.util.DataSourceFactory;
import com.cg.uas.entities.Applicant;
//import com.cg.uas.entities.Application;
import com.cg.uas.exceptions.UasException;

public class MacDAOImpl implements MacDAO{
	
	private DataSource dataSource;
	
	public MacDAOImpl() throws UasException{
		DataSourceFactory factory=new DataSourceFactory();
		dataSource=factory.getDataSource();
	}
	@Override
	public ArrayList<Applicant> viewApplications(String scheduledProgramId) throws UasException {
		Connection connect=null;
//				dataSource.getConnection();
		PreparedStatement stmt=null;
		
		String qry=
				"SELECT Application_id,full_name, date_of_birth, highest_qualification,"
				+ " marks_obtained, goals, email_id, Scheduled_program_id, "
				+ "status, Date_Of_Interview from Application where Scheduled_program_id=?";
		ResultSet rs = null;
		 ArrayList<Applicant> appList=new ArrayList<Applicant>();
		 System.out.println("view() 1");
		 
//		try(Connection connect=dataSource.getConnection();
//			PreparedStatement stmt=connect.prepareStatement(qry);
//			)
		try	
		{
			connect=dataSource.getConnection();
			stmt=connect.prepareStatement(qry);
			System.out.println("view() 2");
			stmt.setString(1,scheduledProgramId);
			rs=stmt.executeQuery();
			System.out.println("view() 3");
			while(rs.next()){
				String applicationId=rs.getString(1);
				String fullName=rs.getString(2);
				String dateOfBirth=rs.getString(3);
				String highestQualification=rs.getString(4);
				int marksObtained=rs.getInt(5);
				String goals=rs.getString(6);
				String emailId=rs.getString(7);
				String scheduledProgramId1=rs.getString(8);
				String appstatus=rs.getString(9);
				String dateOfInterview=rs.getString(10);
				System.out.println("view() 4");
				Applicant appl=new Applicant(applicationId, fullName, dateOfBirth, highestQualification, marksObtained, goals, emailId, scheduledProgramId1, appstatus, dateOfInterview);
				appList.add(appl);
			}
			return appList;
		} catch (SQLException e) {
			
			throw new UasException("Exception from viewApplications()",e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new UasException("Exception from viewApplications()",e);
				}
			}
		}
	}

	@Override
	public int updateStatus(String applicationId) throws UasException {
		
		String currentStatus=checkStatus(applicationId);
		if(currentStatus.isEmpty()){
			return 1;
		}
		if(currentStatus.equals("Accepted")){
			return 2;
		}
		return 0;
	}

	public String checkStatus(String applicationId) throws UasException{
		String qry="SELECT status from Application where Application_id=?";
		ResultSet rs=null;
		try(
				Connection connect=dataSource.getConnection();
				PreparedStatement pStmt=connect.prepareStatement(qry);){
			
			pStmt.setString(1, applicationId);	
			rs=pStmt.executeQuery();
			while(rs.next()){
				String status=rs.getString(1);
				return status;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new UasException("Exception from checkStatus()",e);
		}
		finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new UasException("Exception from checkStatus()",e);
				}
			}
		}
		return null;
	}
	@Override
	public boolean setStatus(String status, String applicationId) throws UasException {
		String qry="UPDATE application SET status=? WHERE Application_id=?";
		try(
				Connection connect=dataSource.getConnection();
				PreparedStatement pStmt=connect.prepareStatement(qry);){
			
			pStmt.setString(1, status);	
			pStmt.setString(2, applicationId);
			int recsUpdated=pStmt.executeUpdate();
			return recsUpdated==1?true:false;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new UasException("Exception from updateStatus()",e);
		}
		}
}
