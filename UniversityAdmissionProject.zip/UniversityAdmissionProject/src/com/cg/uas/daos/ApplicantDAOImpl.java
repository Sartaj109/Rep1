package com.cg.uas.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;
import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exceptions.UasException;
import com.cg.uas.util.DataSourceFactory;

public class ApplicantDAOImpl implements ApplicantDAO {
	private DataSource dataSource;
	public ApplicantDAOImpl() throws UasException {
		DataSourceFactory dataSourceFactory = new DataSourceFactory(); // Create instance of data source factory
		dataSource = dataSourceFactory.getDataSource(); // Initialize the data source
	}
	@Override
	public Programs_Scheduled viewAllProgramSchedule() throws UasException {
		String query = "select Scheduled_program_id, ProgramName,Location,start_date,end_date,sessions_per_week from Programs_Scheduled";
		try
		(
			Connection connection = dataSource.getConnection(); // Retrieve connection from the data source
			PreparedStatement statement = connection.prepareStatement(query); // Create a prepared statement
		)
		
		{
			Programs_Scheduled psch = new Programs_Scheduled(); // Create instance of patient bean
			ResultSet resultSet = statement.executeQuery(); // Execute query and obtain result set
			
			while(resultSet.next())
			{
				psch.setScheduledProgramId(resultSet.getString(1));
				psch.setProgramName(resultSet.getString(2));
				psch.setLocation(resultSet.getString(3));
				psch.setStartDate(resultSet.getString(4));
				psch.setEndDate(resultSet.getString(5));
				psch.setSessionsPerWeek(resultSet.getInt(6));
				//logger.info("Patient details found"); // Log event
				return psch;
			}
			
			return null;
		}
		catch(SQLException e)
		{
			//logger.fatal(e); // Log runtime exception
			throw new UasException("Cannot get list");
		}

	}

	@Override
	public String addNewApplicant(Applicant app) throws UasException, SQLException {
		String query = "insert into Application values(?,?,?,?,?,?,?,?,null,null)";
		try
		(
			Connection connection = dataSource.getConnection(); // Retrieve connection from the data source
			PreparedStatement statement = connection.prepareStatement(query); // Create a prepared statement
		)
		
		{
			String appId=null;
			try {
				appId=generateApplicationId(app.getScheduledProgramId());
				statement.setString(1, appId);
				statement.setString(2, app.getFullName());
				statement.setString(3, app.getDateOfBirth());
				statement.setString(4, app.getHighestQualification());
				statement.setInt(5, app.getMarksObtained());
				statement.setString(6, app.getGoals());
				statement.setString(7, app.getEmailId());
				statement.setString(8, app.getScheduledProgramId());
				statement.execute();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return appId;
		}
	}

	@Override
	public Applicant getApplicantStatus(String applicationId) throws UasException, SQLException {
		String query = "select Application_id,full_name,Scheduled_program_id,status from Application where Application_id=?";
		try
		(
			Connection connection = dataSource.getConnection(); // Retrieve connection from the data source
			PreparedStatement statement = connection.prepareStatement(query); // Create a prepared statement
		)
		
		{
			Applicant appl = new Applicant(); // Create instance of patient bean
			ResultSet resultSet = statement.executeQuery(); // Execute query and obtain result set
			
			if(resultSet.next())
			{
				appl.setApplicationId(resultSet.getString(1));
				appl.setFullName(resultSet.getString(2));
				appl.setScheduledProgramId(resultSet.getString(3));
				appl.setStatus(resultSet.getString(4));
				return appl;
			}
		}
		return null;
	}
	
	public String generateApplicationId(String scheduledProgramId) throws UasException
	{
		String query = "SELECT applicant_id.nextval from dual";
		String applicationId=null;
		try
		(
			Connection connection = dataSource.getConnection(); // Retrieve connection from the data source
			Statement statement = connection.createStatement(); // Create a statement
			ResultSet resultSet = statement.executeQuery(query); // Execute query and obtain result set
		)
		{
			if(resultSet.next())
			{
				
				applicationId=scheduledProgramId+resultSet.getString(1);
				return applicationId;
			}
			return null;
		}
		
		catch (SQLException e)
		{
			throw new UasException("Cannot generate applicant ID");
		}
		
	}

}
