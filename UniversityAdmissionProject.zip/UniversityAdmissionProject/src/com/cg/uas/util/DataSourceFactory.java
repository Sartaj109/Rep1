package com.cg.uas.util;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.sql.DataSource;

import com.cg.uas.exceptions.UasException;

import oracle.jdbc.pool.OracleDataSource;

public class DataSourceFactory {

	private OracleDataSource ds;
	
	static Logger myLogger =  Logger.getLogger("UniversityAdmissionSystem"); //CoreCustomer040 is project name
	
	public DataSourceFactory() throws UasException //no need to close data source, done automatically
	{
		try {
			ds = new OracleDataSource();
		} 
		catch (SQLException e) {
			myLogger.log(Level.SEVERE,"Creation of factory failed.",e);
			throw new UasException("Creation of factory failed.");
		}
		
		ds.setURL( ProjectProp.getProperty("url")); //get url from ProjectProp file
		ds.setUser(ProjectProp.getProperty("userName"));
		ds.setPassword(ProjectProp.getProperty("password"));
		ds.setDriverType(ProjectProp.getProperty("driverType"));
		myLogger.info("Data Source Created.");
	}
	
	public DataSource getDataSource() //DataSource is an interface provided by javax.sql
	{
		return ds;
		
	}
}