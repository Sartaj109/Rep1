package com.cg.uas.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.uas.exceptions.UasException;

public class DBUtil {
	public static Connection getConnection() throws UasException 
	// throwing the user defined exception
	{
		try {
			
			FileInputStream fis = new FileInputStream("Project.properties");
			// linking the properties file with project
			
			Properties props = new Properties();
			// loading properties from file into project
			
			
			// passing fis object into props (classic case of layered architecture!!)
			props.load(fis);
			
			// Fetching connection statements - url, username and password 
			// from properties file
			String url = props.getProperty("oracle.url");
			String username = props.getProperty("oracle.userName");
			String password = props.getProperty("oracle.password");
			
			// prepping the driver
			Class.forName(props.getProperty("oracle.driver"));
			Connection con = DriverManager.getConnection(url,username,password);
			
			return con;
			
		} catch (FileNotFoundException e) {
			throw new UasException (e.getMessage());
		} catch (IOException e) {
			throw new UasException(e.getMessage());
		} catch (ClassNotFoundException e) {
			throw new UasException(e.getMessage());
		} catch (SQLException e) {
			throw new UasException(e.getMessage());
		}
		
	}
}
