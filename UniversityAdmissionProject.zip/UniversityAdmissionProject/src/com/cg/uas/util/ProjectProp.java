package com.cg.uas.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ProjectProp {

private static Properties projProps;
	
	static
	{
		try {
			projProps = new Properties();

			FileReader reader = new FileReader("Config//Project.properties");
			projProps.load(reader);
		} 
		catch (FileNotFoundException e) {
//			e.printStackTrace();
		} catch (IOException e) {
//			e.printStackTrace();
		}
	}
	
	public static String getProperty(String key)
	{
		return projProps.getProperty(key);
	}

	//For the purpose of testing only
	public static void main(String[] args) {
		System.out.println(ProjectProp.getProperty("url"));
	}
}