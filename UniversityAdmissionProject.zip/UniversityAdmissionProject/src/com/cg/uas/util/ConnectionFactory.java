package com.cg.uas.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.uas.exceptions.UasException;


public class ConnectionFactory {

	private Connection connect;
	
	public ConnectionFactory() throws UasException
	{
	//We don't need object to access ProjectProp, as static block of project prop is being executed first
	String url = ProjectProp.getProperty("url");
	String userName = ProjectProp.getProperty("userName");
	String password=ProjectProp.getProperty("password");
		try {
			connect = DriverManager.getConnection(url,userName,password);
		} 
		catch (SQLException e) {
			throw new UasException("Exception from connection factory constructor",e);
		}
	}

	public Connection getConnection() {
		return connect;
	}
}