package com.cg.uas.services;

import java.sql.SQLException;

import com.cg.uas.daos.ApplicantDAO;
import com.cg.uas.daos.ApplicantDAOImpl;
import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exceptions.UasException;

public class ApplicantServiceImpl implements ApplicantService{
	private ApplicantDAO appDao;
	
	
	public ApplicantServiceImpl() throws UasException {
		appDao=new ApplicantDAOImpl();
	}

	@Override
	public Programs_Scheduled viewAllProgramSchedule() throws UasException {
		return appDao.viewAllProgramSchedule();
	}

	@Override
	public String addNewApplicant(Applicant app) throws UasException, SQLException {
		return appDao.addNewApplicant(app);
	}

	@Override
	public Applicant getApplicantStatus(String applicationId) throws UasException, SQLException {
		return appDao.getApplicantStatus(applicationId);
	}

}