package com.cg.uas.services;

import java.util.ArrayList;

import com.cg.uas.entities.Applicant;
import com.cg.uas.exceptions.UasException;

public interface MacService {
	ArrayList<Applicant> viewApllications(String scheduledProgramId) throws UasException;
	int updateStatus(String applicationId) throws UasException;
	boolean setStatus(String status,String applicationId) throws UasException;
}