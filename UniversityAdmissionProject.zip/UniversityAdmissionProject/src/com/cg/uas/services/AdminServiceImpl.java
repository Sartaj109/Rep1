package com.cg.uas.services;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.uas.daos.AdminDAO;
import com.cg.uas.daos.AdminDAOImpl;
import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Offered;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exceptions.UasException;

public class AdminServiceImpl implements AdminService {
	private AdminDAO adminDao;
	public AdminServiceImpl() throws UasException
	{
		adminDao=new AdminDAOImpl();
	}
	@Override
	public boolean addProgram(Programs_Offered po) throws UasException, SQLException {
		return adminDao.addProgram(po);
	}

	@Override
	public boolean deleteProgram(String programName) throws UasException, SQLException {
		return adminDao.deleteProgram(programName);
	}

	@Override
	public boolean updateProgram(String programName, String newData, int choice) throws UasException, SQLException {
		return adminDao.updateProgram(programName, newData, choice);
	}

	@Override
	public String addSchedule(Programs_Scheduled ps) throws UasException, SQLException {
		return adminDao.addSchedule(ps);
	}

	@Override
	public boolean deleteSchedule(String scheduledProgramId) throws UasException, SQLException {
		return adminDao.deleteSchedule(scheduledProgramId);
	}

	@Override
	public ArrayList<Applicant> getApplicantList(String status) throws UasException, SQLException {
		return adminDao.getApplicantList(status);
	}

	@Override
	public ArrayList<Programs_Scheduled> getProgramSchedule(String startDate, String endDate) throws UasException, SQLException {
		return adminDao.getProgramSchedule(startDate, endDate);
	}

}