package com.cg.uas.services;

import java.util.ArrayList;

import com.cg.uas.daos.MacDAO;
import com.cg.uas.daos.MacDAOImpl;
import com.cg.uas.daos.MacDAO;
import com.cg.uas.daos.MacDAOImpl;
import com.cg.uas.entities.Applicant;
import com.cg.uas.exceptions.UasException;

public class MacServiceImpl implements MacService {
	private MacDAO macDao;
	public MacServiceImpl() throws UasException {
		macDao=new MacDAOImpl();
	}
	@Override
	public ArrayList<Applicant> viewApllications(String scheduledProgramId) throws UasException {
		return macDao.viewApplications(scheduledProgramId);
	}

	@Override
	public int updateStatus(String applicationId) throws UasException {
		return macDao.updateStatus(applicationId);
	}

	@Override
	public boolean setStatus(String status, String applicationId) throws UasException {
		return macDao.setStatus(status, applicationId);
	}

}