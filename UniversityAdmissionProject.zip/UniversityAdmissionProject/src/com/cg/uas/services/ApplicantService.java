package com.cg.uas.services;

import java.sql.SQLException;

import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exceptions.UasException;

public interface ApplicantService {
	Programs_Scheduled viewAllProgramSchedule() throws UasException;
	String addNewApplicant(Applicant app) throws UasException, SQLException;
	Applicant getApplicantStatus(String applicationId) throws UasException, SQLException;
}