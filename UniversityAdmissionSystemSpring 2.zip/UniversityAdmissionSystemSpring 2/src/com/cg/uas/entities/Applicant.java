package com.cg.uas.entities;

import java.io.Serializable;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Application")
public class Applicant implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="applicant_gen", sequenceName="applicant_id", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="applicant_gen")
	@Column(name="Application_id")
	private int applicationId;
	
	@Column(name="full_name")
	@NotEmpty
	@Pattern(regexp="[A-Z]{1}[a-zA-Z ]{3,19}", message="Allows alphabets and first should be capital")
	private String fullName;
	
	@Column(name="date_of_birth")
	@Past
	@Temporal(TemporalType.DATE)
	//@Pattern(regexp="[0-9]{1}[1-9]{1}[-]{1}[0-9]{1}[0-2]{1}[-][1-2]{1}[0-9]{3}",message="The date should be in dd-mm-yyyy format")
	private Date dateOfBirth;
	
	@Column(name="highest_qualification")
	@NotEmpty
	private String highestQualification;
	@Column(name="marks_obtained")
	private Integer marksObtained;
	
	@Column(name="goals")
	private String goals;
	
	@Column(name="email_id")
	@Email
	@Size(min=10,max=20)
	private String emailId;
	
	@Column(name="Scheduled_program_id")
	private String scheduledProgramId;
	
	@Column(name="status")
	private String status;
	
	@Column(name="Date_Of_Interview")
	@Temporal(TemporalType.DATE)
	private Date dateOfInterview;
	
	public Applicant()
	{
		
	}
	
	@Override
	public String toString() {
		return "Applicant [applicationId=" + applicationId + ", fullName=" + fullName + ", dateOfBirth=" + dateOfBirth
				+ ", highestQualification=" + highestQualification + ", marksObtained=" + marksObtained + ", goals="
				+ goals + ", emailId=" + emailId + ", scheduledProgramId=" + scheduledProgramId + ", status=" + status
				+ ", dateOfInterview=" + dateOfInterview + "]";
	}



	public Applicant(int applicationId, String fullName, Date dateOfBirth, String highestQualification,
			Integer marksObtained, String goals, String emailId, String scheduledProgramId, String status,
			Date dateOfInterview) {
		super();
		this.applicationId = applicationId;
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.highestQualification = highestQualification;
		this.marksObtained = marksObtained;
		this.goals = goals;
		this.emailId = emailId;
		this.scheduledProgramId = scheduledProgramId;
		this.status = status;
		this.dateOfInterview = dateOfInterview;
	}



	public Applicant(String fullName, Date dateOfBirth, String highestQualification,
			Integer marksObtained, String goals, String emailId, String scheduledProgramId, String status,
			Date dateOfInterview) {
		super();
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.highestQualification = highestQualification;
		this.marksObtained = marksObtained;
		this.goals = goals;
		this.emailId = emailId;
		this.scheduledProgramId = scheduledProgramId;
		this.status = status;
		this.dateOfInterview = dateOfInterview;
	}

	public Applicant(String fullName, Date dateOfBirth, String highestQualification, Integer marksObtained,
			String goals, String emailId,String scheduledProgramId,String status) {
		super();
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.highestQualification = highestQualification;
		this.marksObtained = marksObtained;
		this.goals = goals;
		this.emailId = emailId;
		this.scheduledProgramId=scheduledProgramId;
		this.status=status;
	}

	public Applicant(String fullName, Date dateOfBirth,
			String highestQualification, Integer marksObtained, String goals,
			String emailId, String scheduledProgramId) {
		super();
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.highestQualification = highestQualification;
		this.marksObtained = marksObtained;
		this.goals = goals;
		this.emailId = emailId;
		this.scheduledProgramId = scheduledProgramId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + applicationId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Applicant other = (Applicant) obj;
		if (applicationId != other.applicationId)
			return false;
		return true;
	}

	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getHighestQualification() {
		return highestQualification;
	}

	public void setHighestQualification(String highestQualification) {
		this.highestQualification = highestQualification;
	}

	public Integer getMarksObtained() {
		return marksObtained;
	}

	public void setMarksObtained(Integer marksObtained) {
		this.marksObtained = marksObtained;
	}

	public String getGoals() {
		return goals;
	}

	public void setGoals(String goals) {
		this.goals = goals;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getScheduledProgramId() {
		return scheduledProgramId;
	}

	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getDateOfInterview() {
		return dateOfInterview;
	}

	public void setDateOfInterview(Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}
	

}
