package com.cg.uas.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name="Programs_Scheduled")
public class Programs_Scheduled implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="Scheduled_program_id")
	private String scheduledProgramId;
	
	@Column(name="ProgramName")
	private String programName;
	
	@Column(name="Location")
	private String location;
	
	@Column(name="start_date")
	@Temporal(TemporalType.DATE)
	private Date startDate;
	
	@Column(name="end_date")
	@Temporal(TemporalType.DATE)
	private Date endDate;
	
	@Column(name="sessions_per_week")
	private Integer sessionsPerWeek;
	
	/*@AssertTrue
	public boolean isValidRange(){
		return endDate.compareTo(startDate)>=0;
	}*/
	
	public Programs_Scheduled() {
		super();
	}
	public Programs_Scheduled(String scheduledProgramId, String programName, String location, Date startDate,
			Date endDate, Integer sessionsPerWeek) {
		super();
		this.scheduledProgramId = scheduledProgramId;
		this.programName = programName;
		this.location = location;
		this.startDate = startDate;
		this.endDate = endDate;
		this.sessionsPerWeek = sessionsPerWeek;
	}
	
	public String getScheduledProgramId() {
		return scheduledProgramId;
	}
	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Integer getSessionsPerWeek() {
		return sessionsPerWeek;
	}
	public void setSessionsPerWeek(Integer sessionsPerWeek) {
		this.sessionsPerWeek = sessionsPerWeek;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((scheduledProgramId == null) ? 0 : scheduledProgramId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Programs_Scheduled other = (Programs_Scheduled) obj;
		if (scheduledProgramId == null) {
			if (other.scheduledProgramId != null)
				return false;
		} else if (!scheduledProgramId.equals(other.scheduledProgramId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Programs_Scheduled [scheduledProgramId=" + scheduledProgramId
				+ ", programName=" + programName + ", location=" + location
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", sessionsPerWeek=" + sessionsPerWeek + "]";
	}
	
	
}
