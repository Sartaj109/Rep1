package com.cg.uas.services;

import java.sql.SQLException;
import java.util.List;

import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exception.UasException;

/************************************************************************************
 * File:        ApplicantService.java
 * Package:     com.cg.uas.services
 * Desc:        interface for applicant service operations
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	15/12/2017  
 * Modifications:  
 * Change Description:
 ************************************************************************************/
public interface ApplicantService {
	/**
	 * 
	 * @return List<Programs_Scheduled>
	 * @throws UasException
	 */
	List<Programs_Scheduled> viewAllProgramSchedule() throws UasException;
	/**
	 * 
	 * @param app
	 * @return Applicant
	 * @throws UasException
	 * @throws SQLException
	 */
	Applicant addNewApplicant(Applicant app) throws UasException, SQLException;
	/**
	 * 
	 * @param applicationId
	 * @return Applicant
	 * @throws UasException
	 * @throws SQLException
	 */
	Applicant getApplicantStatus(int applicationId) throws UasException, SQLException;
	/**
	 * 
	 * @param scheduledProgramId
	 * @return boolean
	 * @throws UasException
	 * @throws SQLException
	 */
	boolean checkScheduleProgram(String scheduledProgramId) throws UasException, SQLException;
	/**
	 * 
	 * @param applicationId
	 * @return boolean
	 * @throws UasException
	 * @throws SQLException
	 */
	boolean checkApplicationId(String applicationId) throws UasException, SQLException;
}
