package com.cg.uas.services;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Offered;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exception.UasException;

/************************************************************************************
 * File:        AdminService.java
 * Package:     com.cg.uas.services
 * Desc:        interface for admin service operations
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	15/12/2017  
 * Modifications:  
 * Change Description:
 ************************************************************************************/
public interface AdminService {
	
	/**
	 * 
	 * @param po
	 * @return boolean
	 * @throws UasException
	 * @throws SQLException
	 */
	Programs_Offered addProgram(Programs_Offered po) throws UasException, SQLException;
	/**
	 * 
	 * @param programName
	 * @return boolean
	 * @throws UasException
	 * @throws SQLException
	 */
	boolean deleteProgram(String programName) throws UasException, SQLException;
	/**
	 * 
	 * @param prgmOffered
	 * @return Programs_Offered
	 * @throws UasException
	 * @throws SQLException
	 */
	boolean updateProgram(Programs_Offered prgmOffered) throws UasException, SQLException;
	/**
	 * 
	 * @param ps
	 * @return String
	 * @throws UasException
	 * @throws SQLException
	 */
	Programs_Scheduled addSchedule(Programs_Scheduled ps) throws UasException, SQLException; 
	/**
	 * 
	 * @param scheduledProgramId
	 * @return boolean
	 * @throws UasException
	 * @throws SQLException
	 */
	boolean deleteSchedule(String scheduledProgramId) throws UasException, SQLException;
	/**
	 * 
	 * @param status
	 * @return ArrayList<Applicant>
	 * @throws UasException
	 * @throws SQLException
	 */
	List<Applicant> getApplicantList(String scheduleId,String status) throws UasException, SQLException;
	/**
	 * 
	 * @param start
	 * @param end
	 * @return ArrayList<Programs_Scheduled>
	 * @throws UasException
	 * @throws SQLException
	 */
	List<Programs_Scheduled> getProgramSchedule(String start,String end) throws UasException, SQLException, ParseException;
	/**
	 * 
	 * @param scheduledProgramId
	 * @return boolean 
	 * @throws UasException
	 * @throws SQLException
	 */
	public Programs_Scheduled checkScheduleProgram(String scheduledProgramId) throws UasException, SQLException;
	/**
	 * 
	 * @param programName
	 * @return boolean
	 * @throws UasException
	 * @throws SQLException
	 */
	public Programs_Offered checkProgramName(String programName) throws UasException, SQLException;
	/**
	 * 
	 * @return List<Programs_Scheduled>
	 * @throws UasException
	 * @throws SQLException
	 */
	List<Programs_Scheduled> getAllSchedule() throws UasException, SQLException;
	/**
	 * 
	 * @return List<Programs_Offered
	 * @throws UasException
	 * @throws SQLException
	 */
	List<Programs_Offered> getAllPrograms() throws UasException, SQLException;

}
