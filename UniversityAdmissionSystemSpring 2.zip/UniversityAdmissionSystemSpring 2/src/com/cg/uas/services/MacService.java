package com.cg.uas.services;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.cg.uas.entities.Applicant;
import com.cg.uas.exception.UasException;

/************************************************************************************
 * File:        MacService.java
 * Package:     com.cg.uas.services
 * Desc:        interface for Mac service operations
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	15/12/2017  
 * Modifications:  
 * Change Description:
 ************************************************************************************/
public interface MacService {
	/**
	 * 
	 * @param scheduledProgramId
	 * @return ArrayList<Applicant>
	 * @throws UasException
	 */
	List<Applicant> viewApllications(String scheduledProgramId) throws UasException;
	/**
	 * 
	 * @param applicationId
	 * @return int
	 * @throws UasException
	 */
	int updateStatus(Applicant applicationId) throws UasException;
	/**
	 * 
	 * @param status
	 * @param applicationId
	 * @return boolean
	 * @throws UasException
	 */
	/*boolean setStatus(String status,String applicationId) throws UasException;*/
	/**
	 * 
	 * @param applicationId
	 * @return boolean
	 * @throws UasException
	 */
	boolean checkApplicationId(String applicationId) throws UasException;
	/**
	 * 
	 * @param applicationId
	 * @return String
	 * @throws UasException
	 */
	/*public String getStatus(String applicationId) throws UasException;*/
	/**
	 * 
	 * @param status
	 * @param applicationId
	 * @param dateOfInterview
	 * @return boolean
	 * @throws UasException
	 * @throws ParseException
	 */
	/*public boolean setStatus(String status, String applicationId,LocalDate dateOfInterview) throws UasException,ParseException;*/
	/**
	 * 
	 * @param scheduledProgramId
	 * @return boolean
	 * @throws UasException
	 * @throws SQLException
	 */
	public boolean checkScheduleProgram(String scheduledProgramId) throws UasException, SQLException;

	public boolean executeupdate(int applicantId,String status) throws UasException,SQLException;
	
	public Applicant getApplicant(int applicationId) throws UasException;
	
	public boolean executeupdate(int applicantId,String status,Date dateOfInterview) throws UasException,SQLException;
}
