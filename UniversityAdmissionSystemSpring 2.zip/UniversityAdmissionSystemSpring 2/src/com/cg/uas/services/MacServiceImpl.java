package com.cg.uas.services;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.uas.daos.MacDao;
import com.cg.uas.entities.Applicant;
import com.cg.uas.exception.UasException;

/************************************************************************************
 * File:        MacServiceImpl.java
 * Package:     com.cg.uas.services
 * Desc:        class implementing Mac service interface
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	25/06/2018  
 * Modifications:  
 * Change Description:
 ************************************************************************************/
@Service
@Transactional(rollbackOn=UasException.class)
public class MacServiceImpl implements MacService {
	
	@Autowired
	private MacDao macDao;
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.MacService#viewApllications(java.lang.String)
	 * description: calls the viewApplications method in Mac Dao
	 */
	@Override
	public List<Applicant> viewApllications(String scheduledProgramId) throws UasException {
		return macDao.viewApplications(scheduledProgramId);
	}

	
	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.MacService#updateStatus(java.lang.String)
	 * description: calls the updatestatus method in Mac Dao
	 */
	@Override
	public int updateStatus(Applicant applicationId) throws UasException {
		return macDao.updateStatus(applicationId);
	}

	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.MacService#setStatus(java.lang.String, java.lang.String)
	 * description: calls the setStatus method in Mac Dao
	 */
	/*@Override
	public boolean setStatus(String status, String applicationId) throws UasException {
		return macDao.setStatus(status, applicationId);
	}*/
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.MacService#checkApplicationId(java.lang.String)
	 * description:  calls the checkApplicationId method in Mac Dao
	 */
	@Override
	public boolean checkApplicationId(String applicationId) throws UasException {
		return macDao.checkApplicationId(applicationId);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.MacService#getStatus(java.lang.String)
	 * description:  calls the getStatus method in Mac Dao
	 */
	/*@Override
	public String getStatus(String applicationId) throws UasException {
		return macDao.getStatus(applicationId);
	}*/
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.MacService#setStatus(java.lang.String, java.lang.String, java.time.LocalDate)
	 * description:  calls the setStatus method in Mac Dao
	 */
	/*@Override
	public boolean setStatus(String status, String applicationId,LocalDate dateOfInterview) throws UasException,ParseException {
		return macDao.setStatus(status, applicationId, dateOfInterview);
	}*/
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.MacService#checkScheduleProgram(java.lang.String)
	 * description:  calls the checkSheduleProgram method in Mac Dao 
	 */
	@Override
	public boolean checkScheduleProgram(String scheduledProgramId) throws UasException, SQLException {
		return macDao.checkScheduleProgram(scheduledProgramId);
	}


	@Override
	public boolean executeupdate(int applicantId, String status)
			throws UasException, SQLException {
		return macDao.executeupdate(applicantId, status);
	}


	@Override
	public Applicant getApplicant(int applicationId) throws UasException {
		return macDao.getApplicant(applicationId);
	}
	
	
	public boolean executeupdate(int applicantId,String status,Date dateOfInterview) throws UasException,SQLException
	{
		return macDao.executeupdate(applicantId, status, dateOfInterview);
	}
}
