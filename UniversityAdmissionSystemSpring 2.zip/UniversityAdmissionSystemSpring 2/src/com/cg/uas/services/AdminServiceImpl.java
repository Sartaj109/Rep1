package com.cg.uas.services;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.uas.daos.AdminDAO;
import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Offered;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exception.UasException;

/************************************************************************************
 * File:        AdminServiceImpl.java
 * Package:     com.cg.uas.services
 * Desc:        class implementing admin service interface
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      25/06/2018
 * Modifications:  
 * Change Description:
 ************************************************************************************/
@Service
@Transactional(rollbackOn=UasException.class)
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminDAO adminDao;
	
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.AdminService#addProgram(com.cg.uas.entities.Programs_Offered)
	 * description: calls the addProgram method in admin dao 
	 */
	@Override
	public Programs_Offered addProgram(Programs_Offered po) throws UasException, SQLException {
		return adminDao.addProgram(po);
	}

	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.AdminService#deleteProgram(java.lang.String)
	 * description: calls the deleteProgram method in admin dao 
	 */
	@Override
	public boolean deleteProgram(String programName) throws UasException, SQLException {
		return adminDao.deleteProgram(programName);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.AdminService#updateProgram(com.cg.uas.entities.Programs_Offered)
	 * description: calls the updateProgram method in admin dao 
	 */
	@Override
	public boolean updateProgram(Programs_Offered prgmOffered)
			throws UasException, SQLException {
		return adminDao.updateProgram(prgmOffered);
	}

	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.AdminService#addSchedule(com.cg.uas.entities.Programs_Scheduled)
	 * description: calls the add schedule method in admin dao 
	 */
	@Override
	public Programs_Scheduled addSchedule(Programs_Scheduled ps) throws UasException, SQLException {
		return adminDao.addSchedule(ps);
	}

	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.AdminService#deleteSchedule(java.lang.String)
	 * description: call the delete schedule method in admin dao 
	 */
	@Override
	public boolean deleteSchedule(String scheduledProgramId) throws UasException, SQLException {
		return adminDao.deleteSchedule(scheduledProgramId);
	}

	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.AdminService#getApplicantList(java.lang.String)
	 * descrption: call the getApplicant list in admin dao 
	 */
	@Override
	public List<Applicant> getApplicantList(String scheduleId, String status)throws UasException, SQLException {
		return adminDao.getApplicantList(scheduleId, status);
	}

	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.AdminService#getProgramSchedule(java.time.LocalDate, java.time.LocalDate)
	 * description: call the get programs scheduled method in admin dao
	 */
	@Override
	public List<Programs_Scheduled> getProgramSchedule(String startDate, String endDate) throws UasException, SQLException, ParseException {
		return adminDao.getProgramSchedule(startDate, endDate);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.AdminService#checkScheduleProgram(java.lang.String)
	 * description: calls the checkScheduleProgram method in admin dao
	 */
	@Override
	public Programs_Scheduled checkScheduleProgram(String scheduledProgramId) throws UasException, SQLException {
		return adminDao.checkScheduleProgram(scheduledProgramId);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.AdminService#checkProgramName(java.lang.String)
	 * description: calls the checkProgramName method in admin dao
	 */
	@Override
	public Programs_Offered checkProgramName(String programName) throws UasException, SQLException {
		return adminDao.checkProgramName(programName);
	}

	@Override
	public List<Programs_Scheduled> getAllSchedule() throws UasException,
			SQLException {
		return adminDao.getAllSchedule();
	}

	@Override
	public List<Programs_Offered> getAllPrograms() throws UasException,
			SQLException {
		return adminDao.getAllPrograms();
	}

}
