package com.cg.uas.daos;

import java.sql.SQLException;

import com.cg.uas.entities.Users;
import com.cg.uas.exception.UasException;


/************************************************************************************
 * File:        LoginDAO.java
 * Package:     com.cg.uas.daos
 * Desc:        interface for login dao operations
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	15/12/2017  
 * Modifications:  
 * Change Description:
 ************************************************************************************/

public interface LoginDao {
	/**
	 * 
	 * @param userName
	 * @param password
	 * @return String
	 * @throws SQLException
	 * @throws UasException
	 */
	Users verifyUser(String userName) throws SQLException,UasException;
}
