package com.cg.uas.daos;

import java.util.Date;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exception.UasException;


/************************************************************************************
 * File:        ApplicantDAOImpl.java
 * Package:     com.cg.uas.daos
 * Desc:        class implementing applicant dao interface
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	25/06/2018 
 * Modifications:  
 * Change Description:
 ************************************************************************************/
@Repository
public class ApplicantDAOImpl implements ApplicantDAO {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	private static Logger myLogger =  Logger.getLogger("UniversityAdmissionSystem");

	@Override
	public List<Programs_Scheduled> viewAllProgramSchedule() throws UasException {
			try {
				TypedQuery<Programs_Scheduled> query = entityManager.createQuery("SELECT p FROM Programs_Scheduled p", Programs_Scheduled.class);
				myLogger.info("Retrived all scheduled programs");
				return query.getResultList();
			} catch (Exception e) {
				myLogger.fatal("Retrived all scheduled programs");
				throw new UasException("retrive failed"+e.getMessage());
			}
	}

	@Override
	public Applicant addNewApplicant(Applicant applicant) throws UasException,
			SQLException {
		try {
			Date date= null;
			applicant.setDateOfInterview(date);
			applicant.setStatus("Pending");
			entityManager.persist(applicant);
			entityManager.flush();
			myLogger.info("Applicant added successfully.");
			return applicant;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return applicant;
	}

	@Override
	public Applicant getApplicantStatus(int applicationId)
			throws UasException, SQLException {
		Applicant applicant = entityManager.find(Applicant.class, applicationId);
		myLogger.info("Status recieved");
		return applicant;
	}

	@Override
	public boolean checkScheduleProgram(String scheduledProgramId)
			throws UasException, SQLException {
		entityManager.find(Programs_Scheduled.class, scheduledProgramId);
		return true;
	}

	@Override
	public boolean checkApplicationId(String applicationId)
			throws UasException, SQLException {
		entityManager.find(Applicant.class, applicationId);
		myLogger.info("Applicant found");
		return true;
	}	
}
