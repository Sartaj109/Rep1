package com.cg.uas.daos;

import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;



import com.cg.uas.entities.Users;
import com.cg.uas.exception.UasException;


/************************************************************************************
 * File:        LoginDAOImpl.java
 * Package:     com.cg.uas.daos
 * Desc:        class implementing login dao interface
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	25/06/2018  
 * Modifications:  
 * Change Description:
 ************************************************************************************/
@Repository
public class LoginDaoImpl implements LoginDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	
	private static Logger myLogger =  Logger.getLogger("UniversityAdmissionSystem");
	
	
	@Override
	public Users verifyUser(String userName) throws SQLException, UasException {
		
			Users user,user1;
			
		
				user = entityManager.find(Users.class, userName);
//				Query query = entityManager.createQuery("from users where LOGIN_ID=:userName");
				System.out.println("Role: "+user.getRole());
				System.out.println("Password: "+user.getPassword());
				System.out.println("name in dao is:"+userName);
				System.out.println("User is : " + user);
				myLogger.info("Successful login");
				user1=user;
				System.out.println("user1 is : "+user1);
				
			return user1;
	}
}
