package com.cg.uas.daos;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Participant;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exception.UasException;

/************************************************************************************
 * File:        MacDaoImpl.java
 * Package:     com.cg.uas.daos
 * Description:        class implementing mac dao interface
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	25/06/2018 
 * Modifications:  
 * Change Description:
 ************************************************************************************/
@Repository
public class MacDaoImpl implements MacDao{
	
	@PersistenceContext
	private EntityManager entityManager;

	
	private static Logger myLogger =  Logger.getLogger("UniversityAdmissionSystem");
	
	
	@Override
	public List<Applicant> viewApplications(String scheduledProgramId)
			throws UasException {
		TypedQuery<Applicant> query = entityManager.createQuery("SELECT a FROM Applicant a WHERE a.scheduledProgramId = :id", Applicant.class);
		query.setParameter("id", scheduledProgramId);
		myLogger.info("Retrived all applicant");
		return query.getResultList();
	}

	@Override
	public int updateStatus(Applicant applicant) throws UasException {
		entityManager.merge(applicant);
		myLogger.info("Update status success");
		return 1;
	}

	

	@Override
	public boolean checkApplicationId(String applicationId) throws UasException {
		entityManager.find(Applicant.class, applicationId);
		return false;
	}



	@Override
	public boolean checkScheduleProgram(String scheduledProgramId)
			throws UasException, SQLException {
		entityManager.find(Programs_Scheduled.class, scheduledProgramId);
		return false;
	}
	
	@Override
	public Applicant getApplicant(int applicationId) throws UasException {
		Applicant app=entityManager.find(Applicant.class, applicationId);
		myLogger.info("Retrived all applicant");
		return app;
	}
	
	@Override
	public boolean executeupdate(int applicantId,String status) throws UasException,SQLException
	{
		Applicant app=entityManager.find(Applicant.class, applicantId);
		app.setStatus(status);
		Applicant newApp=entityManager.merge(app);
		if(status.equals("confirmed"))
		{
			Participant part=new Participant(app.getEmailId(), app.getApplicationId(),app.getScheduledProgramId());
			entityManager.persist(part);
			entityManager.flush();
		}
		if(newApp != null){
			myLogger.info("Update success for applicant");
			return true;
		}	
		else
			return false;
	}
	public boolean executeupdate(int applicantId,String status,Date dateOfInterview) throws UasException,SQLException
	{
		Applicant app=entityManager.find(Applicant.class, applicantId);
		app.setStatus(status);
		app.setDateOfInterview(dateOfInterview);
		Applicant newApp=entityManager.merge(app);
		if(status.equals("confirmed"))
		{
			Participant part=new Participant(app.getEmailId(), app.getApplicationId(),app.getScheduledProgramId());
			entityManager.persist(part);
			entityManager.flush();
		}
		if(newApp != null){
			myLogger.info("Update success for applicant");
			return true;
		}
		else
			return false;
	}
}

